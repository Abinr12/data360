from django.apps import AppConfig


class Data360ApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Data360API'
